Centered alignment metric learning (CAML)
Batch CAML.m mini-batch case for large datasets with vectors in Euclidean space CAML_approx.m

Batch algorithm requires Mark Schmidt's minFunc toolbox 
https://www.cs.ubc.ca/~schmidtm/Software/minFunc.html

Test script cmd_simple_test.m