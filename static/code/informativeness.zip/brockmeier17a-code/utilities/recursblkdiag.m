function B=recursblkdiag(x)
B=[];
for size_ii=x(:)'
    B=blkdiag(B,ones(size_ii));
end
end