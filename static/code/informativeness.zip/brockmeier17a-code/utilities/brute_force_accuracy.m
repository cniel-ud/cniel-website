function acc=brute_force_accuracy(x,y)
assert(numel(x)==numel(y),'input vectors must be the same length\n')
[a,~,x]=unique(x);
[b,~,y]=unique(y);

C=max(numel(a),numel(b));
if max(numel(a),numel(b)) >7
    fprintf('Brute force is not recommended. Solve the LAP using the hungarian.')
end

G=zeros(C,C);
for c=1:C
    for r=1:C
        G(c,r)=sum(y==c & x==r);
    end
end
V=perms(1:C);
acc=1/numel(x)*max(sum(G(sub2ind([C,C],repmat((1:C).',1,size(V,1)),V.')),1));
end