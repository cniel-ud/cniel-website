function [ K12 ] = safe_sqrtm(K)

[U,L]=eig(full((K+K')/2));
K12=U*sqrt(L.*(L>0))*U';

end

