function  h=mat2patch( C )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[m,n]=size(C);
[xx,yy]=meshgrid(0:1/n:1-1/n,0:1/m:1-1/m);


%x=[0;0;1/n;1/n;0];
%y=[0;1/n;1/n;0;0];
%n_rep=1;

% n_rep=2;
% x=[0   0;
%    0  1/n;
%   1/n 1/n;
%    0   0];
% y=[0 1/n;
%    1/n 1/n;
%    0  0;
%    0 1/n];

x=[0 0;0 1/n;1/n 1/n;1/n 0;0 0];
y=[0 0 ;1/m 0;1/m 1/m;0 1/m;0 0];
n_rep=2;


x=bsxfun(@plus,repmat(x,1,n*m),kron(xx(:).',ones(1,n_rep)));
y=bsxfun(@plus,repmat(y,1,n*m),kron(yy(:).',ones(1,n_rep)));

h=patch([0 1 1 0 0].',[0 0 1 1 0].',0);
set(h,'edgecolor','k','linewidth',1,'facecolor','none')

h=patch(x,y,kron(reshape(flipud(C),[],1),ones(n_rep,1)));
set(h,'edgecolor','none')

end

