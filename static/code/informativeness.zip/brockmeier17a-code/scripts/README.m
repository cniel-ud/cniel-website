%  The included MATLAB scripts reproduces figures and tables from the paper 
%  Austin J. Brockmeier, Tingting Mu, Sophia Ananiadou, and John Y. Goulermas 
%  "Quantifying the Informativeness of Similarity Measurements",
%  Journal of Machine Learning Research, vol. 18, July, 2017.
% 
% Version 1.0   July 11, 2017    Austin J. Brockmeier
% 
%  DISCLAIMER: THIS SOFTWARE IS PROVIDED BY THE AUTHORS "AS IS" AND ANY 
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
%  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
%  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
%  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
%  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
%  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
%  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
%  THE POSSIBILITY OF SUCH DAMAGE.
% 
%  Warning: some scripts (Table 6, Figure 13, Figure 14, Table 9)
%  require an internet connection in order to download the relevant data
%  sets from online webpages
% 
% To run an individual script (assuming the working directory is
% informativeness/scripts/)
% addpath(genpath('../functions')) % add all the functions and subdirectories
% addpath('../utilities') %add some utility functions
% run cmd_Figure_1_info_embed_vectors.m
%
