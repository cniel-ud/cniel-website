20 Newsgroup data set using the sparse indices provided by Jason Rennie

http://qwone.com/~jason/20Newsgroups/
In particular,
http://qwone.com/~jason/20Newsgroups/20news-bydate-matlab.tgz

When using this data set, please cite Jason Rennie’s version.