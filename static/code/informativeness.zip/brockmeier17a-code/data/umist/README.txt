The UMIST data set Graham et al. 1998 is now the Sheffield Face Database https://www.sheffield.ac.uk/eee/research/iel/research/face. 

This MATLAB version of the UMIST data set is available from Sam Roweis’s website

http://www.cs.nyu.edu/~roweis/data.html


Daniel B. Graham and Nigel M. Allinson. Characterising virtual eigensignatures for general purpose face recognition. In Harry Wechsler, P. Jonathon Phillips, Vicki Bruce, Françoise Fogelman Soulié, and Thomas S. Huang, editors, Face Recognition: From Theory to Applications, pages 446–456. Springer Berlin Heidelberg, 1998.