Matlab files created from downloading UCI datasets 

Please obtain original data sets and details from the UCI repository and cite
 M. Lichman. UCI machine learning repository, 2013. URL http://archive.ics.uci.edu/ml