USPS handwritten digits from Hull 1994 

The USPS digits data were gathered at the Center of Excellence in Document Analysis and Recognition (CEDAR) at SUNY Buffalo, as part of a project sponsored by the US Postal Service. The dataset is described in A Database for Handwritten Text Recognition Research, J. J. Hull, IEEE PAMI 16(5) 550-554, 1994.

Data set hosted on http://web.stanford.edu/~hastie/ElemStatLearn/data.html
In particular 
http://web.stanford.edu/~hastie/ElemStatLearn/datasets/zip.test.gz
http://web.stanford.edu/~hastie/ElemStatLearn/datasets/zip.train.gz

Another source is http://www.gaussianprocess.org/gpml/data/ but the results are slightly different.

When using these images, please give proper credit to the original source.
