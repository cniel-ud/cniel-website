COIL-20 data set available http://www.cs.columbia.edu/CAVE/software/softlib/coil-20.php

The COIL20 data set consists of images of rotated objects Nene et al., available at http://www.cs.columbia.edu/CAVE/software/softlib/coil-20.php


Sameer A. Nene, Shree K. Nayar, and Hiroshi Murase. Columbia object image library (COIL-20). Technical report, CUCS-005-96, 1996.

When using these images, please give proper credit to Nene et al.