The MNIST handwritten digits data set is available from http://yann.lecun.com/exdb/mnist/

Note: only the test set is used.

MATLAB files are created using Andrew Y. Ng’s helper functions available from http://ufldl.stanford.edu/wiki/index.php/Using_the_MNIST_Dataset

LeCun, Yann; Corinna Cortes; Christopher J.C. Burges. "MNIST handwritten digit database, Yann LeCun, Corinna Cortes and Chris Burges".