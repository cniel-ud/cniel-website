The Olivetti Research Laboratory's (ORL) face image data set was previously hosted by AT\&T Cambridge and is now hosted by  Cambridge University Computer Laboratory: \url{http://www.cl.cam.ac.uk/research/dtg/attarchive/facedatabase.html}

When using these images, please give credit to AT&T Laboratories Cambridge.