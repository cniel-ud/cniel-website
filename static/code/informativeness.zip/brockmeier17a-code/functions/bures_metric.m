function [dist_hell,bcoef ] = bures_metric(rho,sigma)
%assumes PSD for both
rho=rho/trace(rho);
sigma=sigma/trace(sigma);
[u,l]=eig(rho);
rho_sqrt=u*diag(sqrt(diag(l)));
[u,l]=eig(sigma);
sigma_sqrt=u*diag(sqrt(diag(l)));
bcoef=sum(svd(rho_sqrt'*sigma_sqrt));
bcoef=min(1,bcoef);
dist_hell=sqrt(2-2*bcoef);
end