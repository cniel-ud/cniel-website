function [rez,off_ele] = matrix_info_lawley(rho,do_dist )
n=size(rho,1);
if n>1
rho=rho/trace(rho)*n;%trace of n
k1=sum(rho);
kbar=mean(rho(:));
rbark=(sum(rho,2)-1)/(n-1);
rbar=mean(rbark);%=(kbar*n-1)/(n-1)
lambda=(1-rbar);
mu=(n-1)^2*(1-lambda^2)/(n-(n-2)*lambda^2);


if lambda>0
%T5=1/lambda^2*(sum(sum(tril(rho-rbar,-1).^2))-mu*sum((rbar-rbark).^2));
%T52=1/lambda^2*(1/2*(rho(:)'*rho(:)-n^2/(n-1)*(n*kbar^2-2*kbar+1))...
%    -(1-lambda^2)/(n-(n-2)*lambda^2)*((k1*k1')-kbar^2*n^3));
T5=1/lambda^2*(1/2*(rho(:)'*rho(:)-n^2/(n-1)*(n*kbar^2-2*kbar+1))...
    -(1-lambda^2)/(n-(n-2)*lambda^2)*norm(k1-n*kbar)^2);
else
    T5=0;
end
a=kbar;
dist=2*T5*lambda^2/n^2;
off_ele=a-(1-a)/(n-1);
else
    dist=0;
    a=1;
    off_ele=1;    
end

if nargin==2 && do_dist==1
    rez=dist;
else
    rez=T5;
end


end

