function dist = bures_lb_embed_info(Z )
%assumes Z is d by n
[m,n]=size(Z);
sqrt_h=sqrt(norm(mean(Z,2))^2 + 1/n/(n-1)*sum(svd(bsxfun(@minus,full(Z),mean(Z,2))))^2);
dist=1-sqrt_h;
end

