function [dist,a,off_ele] = matrix_info_fro_embed_general(Z )
%assumes Z is d by n
N_a=@(a,n) a+(1-a)*n/(n-1)*(eye(n)-1/n);%tr N_a =n 
[m,n]=size(Z);
if n>1
mu=mean(Z,2);
kbar=norm(mu)^2;
    trK=sum(sum(Z.^2,1),2);
    a=kbar+1/n-trK/n^2;
dist=1/n*norm(N_a(a,n)-Z'*Z,'fro');
off_ele=a-(1-a)/(n-1);
else
    dist=0;
    a=1;
    off_ele=1;
end
end

