function dist= matrix_info_cka_embed_general(Z )
%assume d by n
[m,n]=size(Z);
mu=mean(Z,2);

Zc=bsxfun(@minus,Z,mu);
if m<n
    Kcvec=Zc*Zc';
else
    Kcvec=Zc'*Zc;
end
    HKH_fro=sqrt(sum(Kcvec(:).^2));
    trKH=Zc(:)'*Zc(:);
    dist=1-1/sqrt(n-1)*trKH/(eps+HKH_fro);

