function [dist_hell2_2,a,d_ml,a_ml ] = bures_super_lb_matrix_info(rho )
n=size(rho,1);
if trace(rho)>eps
    K=rho/trace(rho)*n;
    K_fro=sqrt(K(:)'*K(:));
    K1=sum(K(:));
    kbar=K1/n^2;
    G_a=@(a) 1/(n-1)*(1-kbar+a*(n*kbar-1))+sqrt(max(0,(1-(K_fro/n)^2)/(n-1)*(n-2-n*a.^2+2*a)));
    
    
    bb=((n*kbar-1)/(n-1))^2;
    cc=(1-(K_fro/n)^2)/(n-1);
    if K_fro==n && kbar==1/n
        G_a=@(a) 1/(n-1)*(1-kbar);    %constant value
    end
    a=(cc*n+bb+sqrt((cc*n+bb)^2-(cc*n^2+bb*n)*(cc+bb*(2-n))))/(cc*n^2+bb*n);
    a2=(cc*n+bb-sqrt((cc*n+bb)^2-(cc*n^2+bb*n)*(cc+bb*(2-n))))/(cc*n^2+bb*n);
    as=[a a2];    
    as=min(1,max(0,as));
    superFidelity=max(G_a(as(1)),G_a(as(2)));
    bcoef=min(1,sqrt(superFidelity));
    dist_hell2_2=1-bcoef;

    a_ml=kbar;
    superFidelity=G_a(a_ml);
    bcoef=min(1,sqrt(superFidelity));
    d_ml=1-bcoef;

else
    dist_hell2_2=0;
    a=1;
    d_ml=0;
    a_ml=1;
end
end

