function dist = matrix_info_cka(K)
n=size(K,1);
K=K/trace(K)*n;
kbar=mean(K);

    KH=bsxfun(@minus,K,kbar);
    HKH=bsxfun(@minus,KH,kbar')+mean(kbar);
    HKH_fro=sqrt(sum(HKH(:).^2));
    kbar=mean(K(:));
    if kbar<1
    dist=1-n/sqrt(n-1)*(1-kbar)/HKH_fro;
    else
        dist=0;
    end
end