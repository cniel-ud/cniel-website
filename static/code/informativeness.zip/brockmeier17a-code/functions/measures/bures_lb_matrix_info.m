function [dist_hell2_2,a ] = bures_lb_matrix_info(rho )

n2=size(rho,1);
keep_idx=diag(rho)>0;
rho=rho(keep_idx,keep_idx);
n=sum(keep_idx);
if trace(rho)>eps

    rho=rho/trace(rho)*n;
    rho=(rho+rho')/2;
%    lambda=eig(rho);
%    if any(lambda<-eps*n)
%        rho=(rho+rho')/2;
%        [u,lambda]=eigs(rho,sum(lambda>eps*n),'la');
%        rho=u*lambda*u';
%     rho=rho/trace(rho)*n;       
%    end
%     
d=mean(rho);
p1=mean(d);


rho_centered=bsxfun(@minus,bsxfun(@minus,rho,d),d')+mean(d);
rho_centered=(rho_centered+rho_centered')/2;
p_rest=eig(rho_centered);% %could use svds since we know rank of rho
p_rest=p_rest(p_rest>0);
p2=1/(n-1)/n*sum(sqrt(p_rest))^2;
a=p1/(p1+p2);

bcoef=min(1,sqrt(p1+p2));
dist_hell2_2=1-bcoef;
%adjust for zeros on diagonal 
dist_hell2_2=n/n2*(dist_hell2_2);

else
    dist_hell2_2=0;
    a=1;
end



end

