function [inf_dist,a,E] = bures_info_fminbnd(rho )

n=size(rho,1);
%assume rho is correlation matrix then normalize it
rho=rho/trace(rho)*n;
[U,S,V]=svd(full(rho));

rho12=U*sqrt(S)*V';
J_a12=@(a) sqrt(a/n)+sqrt((1-a)*n/(n-1))*(eye(n)-1/n);%elliptope matrix
D=@(a) 1-sum(svd(J_a12(a)*rho12))/n;
[a,inf_dist]=fminbnd(D,0,1); 
if nargout>=3
E=(1-a)/(n-1)*(eye(n)-1/n)+a/n;
end


end

