function [Z,keep_rank,u] = infoProx2(Z,lambda)
n=size(Z,2);
Z1=sum(Z,2);
ZH=bsxfun(@minus,Z,Z1/n);
[ZH_prox,keep_rank,u]=SOSST(ZH,2*lambda/n/(n-1));
Z=bsxfun(@plus,Z1/(2*lambda+n),ZH_prox);
end