This distribution contains all of the underlying algorithms for “Learning Recurrent Waveforms within EEGs”  Austin J. Brockmeier and Jose C. Principe.

It includes three examples scripts to demonstrate the methodology. However, it does not include the full scripts used for the extensive data analysis on the BCI competition III dataset IV.

Please contact the first author at ajbrockmeier@gmail.com if you have troubles or questions. The code is for research purposes and due to the inclusion of FastICA is under the GPL license.  Documentation may be lacking especially in shorter data mucking functions in the folders (utilities & mptk_interface).


Three examples:

1) cmd_test_shiftInvarianKmeans.m  (Very quick demo of shift-invariant k-means)

Demonstrates the shift-invariant waveform clustering algorithm that can be used to find centroids of waveforms learned across channels and/or subjects. 

Uses the function
clustering/shiftInvariantKmeans.m
 (assumes waveforms are same length, obviously for different scales, you can simply pad, shorter waveforms with zeros)




2) cmd_toy_learn_decompose_plot.m (Very quick demo of the waveform learning)

Demonstrates waveform learning and decomposition and plotting of decomposition results.

Optionally this can also interface with the matching pursuit toolkit, please see dependencies below.


3) cmd_single_channel_learn.mat (Slower demo that learns waveforms on real dataset and reproduces figures in paper)


Demonstrates waveform learning on the data extracted from the dataset publicly available from the Department of Epileptology at the University Hospital of Bonn. The details of the recording are available in the original publication [76]. 

Andrzejak RG, Lehnertz K, Rieke C, Mormann F, David P, Elger CE, “Indications of nonlinear deterministic and finite-dimensional structures in time series of brain electrical activity: Dependence on recording region and brain state,” Physical Review E, 64, 061907, 2001. 
http://epileptologie-bonn.de/cms/front_content.php?idcat=193&lang=3

The MATLAB datafile in data/data_mat.mat is a collated version of the dataset.

The script demonstrates the three types of waveform learning: model based (MPSVD), ICA based, and Gabor waveform selection:
learning/multistageWaveformLearning.m         Runtime: 117 s
learning/multistageICASelection.m             Runtime: 261 s
learning/multistageGaborSelection.m           Runtime: 258 s

(Run-time is on a MacBook Pro Laptop with 2.8 GHz Intel Core i7 and 16GB RAM)


Then it plots the waveforms, calculating their center frequency and bandwidth. In addition, the waveforms are compared to a discrete set of Gabor wavelets.




Dependencies: 

Dependency on FastICA
To use ICA to learn waveforms, there is a dependency of FastICA (tested with Version 2.5, October 19 2005) Copyright (c) Hugo Gävert, Jarmo Hurri, Jaakko Särelä, and Aapo Hyvärinen.  FastICA is under the GNU Public license (GPL). 

Called in cmd_single_channel_learn.mat by learning/multistageICASelection.m
The folder FastICA_25 should be placed within the same directory as the script.

It can be downloaded from 
http://research.ics.aalto.fi/ica/fastica/
http://research.ics.aalto.fi/ica/fastica/code/dlcode.shtml



[Optional] Dependency on matching pursuit toolkit (MPTK) 
Can be called in cmd_toy_learn_decompose_plot.m by changing line 7 to assign a Boolean true. 

Decomposition of signals onto Gabor wavelets is done use the matching pursuit toolkit (MPTK). 

http://mptk.irisa.fr/downloads
http://mptk.irisa.fr/mptk-users/mptk-users-1/mptk-users-faq


If you are using a Mac, the path to the MATLAB API is assumed to be ‘/usr/local/mptk/matlab’ and the configuration file the controls the paths for MPTK is at ‘/usr/local/mptk/path.xml’  This is done on lines 6-7 of mptk_interface/mptkDecompose_gabor.m

If you are using a PC, you will have to set the Window’s PATH environment variable appropriately and also add the MPTK’s MATLAB API to MATLAB’s path environemnt. This can be done programmatically using the same style as in the Mac case, and should be added at line 9 of mptk_interface/mptkDecompose_gabor.m







